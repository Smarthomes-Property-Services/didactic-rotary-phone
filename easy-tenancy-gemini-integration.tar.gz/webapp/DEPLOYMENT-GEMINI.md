# Gemini production integration (Cloudflare Pages)

The browser should continue to call same-origin `/api/...` routes. Do **not** set the frontend API base to the Google AI Studio editor URL (`https://ai.studio/apps/...`): that is an app workspace URL, not a stable Gemini REST API endpoint or this site's backend API.

## What changed in this patch

- Added a server-side Gemini REST client to `functions/api/[[route]].ts` using `GEMINI_API_KEY` as a Cloudflare Pages secret and the `x-goog-api-key` header.
- Routed `/api/ai/chat`, `/api/ai/describe`, `/api/ai/summarize`, and `/api/ai/retention-email` through Gemini when configured.
- Added `/api/brain/chat`, which is already called by `src/routes/StrategicBrain.tsx` but was missing from the Cloudflare Pages function router.
- Updated the Copilot default model label from `gemini-2.0-flash` to `gemini-2.5-flash`. The backend only allows the configured Flash/Pro model choices; arbitrary client model strings are not passed upstream.
- Kept the existing paths and JSON response fields (`ok`, `response`, `reply`, `model`) to preserve frontend contracts.
- Workers AI fallback is opt-in only: set `CF_AI_FALLBACK_ENABLED=true` as a Pages variable if you explicitly want it. Gemini errors do not silently switch providers.

## Configure the production secret

From the repository checkout, set the secret for the Cloudflare Pages project configured in `wrangler.jsonc` (`weathered-night-72f4`):

```sh
npx wrangler pages secret put GEMINI_API_KEY --project-name weathered-night-72f4
```

Paste the Gemini API key only into the interactive secret prompt. Do not put it in `.env`, `wrangler.jsonc`, source code, a Vite `VITE_*` variable, or GitHub. Verify that the key is restricted/authorized for the Gemini API in Google AI Studio/Google Cloud. Do not include it in test output or logs.

## Build and deploy

```sh
npm ci
npm run typecheck
npm run build
npm test
# Deploy only after reviewing the build and smoke tests:
npx wrangler pages deploy dist --project-name weathered-night-72f4
```

The integration patch was prepared from the uploaded archive. Dependency installation timed out in the editing environment, so the build/test commands could not be completed here; run them in CI or a network-enabled checkout before deployment.

## Production smoke tests

Set `BASE_URL` to the actual public Cloudflare Pages/custom-domain URL (not the AI Studio editor URL):

```sh
curl -fsS "$BASE_URL/api/health"
curl -fsS "$BASE_URL/api/ai/models"
curl -sS -X POST "$BASE_URL/api/ai/chat" \
  -H 'content-type: application/json' \
  --data '{"message":"Reply with exactly: Gemini connection OK","model":"gemini-2.5-flash"}'
curl -sS -X POST "$BASE_URL/api/brain/chat" \
  -H 'content-type: application/json' \
  --data '{"messages":[{"role":"user","content":"Reply with exactly: Brain connection OK"}]}'
```

Expected: `/api/health` returns `status: "ok"`; `/api/ai/models` reports `geminiConfigured: true` and `provider: "gemini"`; chat endpoints return HTTP 200 with `ok: true` and non-empty text. If the secret is missing, AI endpoints return 503 with a configuration error. Gemini quota failures return 429; other upstream errors return 502. Do not smoke-test with tenant personal data.

## Frontend contract

- `POST /api/ai/chat`: request `{ message, context?, model? }`; response `{ ok, response, model, source }`.
- `POST /api/brain/chat`: request `{ messages: [{ role, content }] }`; response `{ ok, reply, source, model }`.
- Existing frontend fetches remain relative (`/api/...`) so they use the same Cloudflare origin and do not need CORS configuration for these calls.
